//
//  ContentView.swift
//  kranio-test
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

import SwiftUI

struct ContentView: View {
    let transactions = [
        Transaction(id: "tx001", accountId: "acc123", type: .debit, amount: 150.75, category: "TRANSFER"),
        Transaction(id: "tx002", accountId: "acc123", type: .credit, amount: 2500.00, category: "SALARY"),
        Transaction(id: "tx003", accountId: "acc123", type: .debit, amount: 75.50, category: "FOOD")
    ]
    
    var summary: AccountSummary {
        TransactionAnalyzer().analyzeTransactions(transactions)
    }

    var body: some View {
        VStack{
            Text("Contigo App").fontWeight(.bold).font(.largeTitle).foregroundStyle(.blue)
            Text("Transacciones").fontWeight(.medium).font(.caption)
                .foregroundStyle(.secondary)
    
                
            VStack(alignment: .leading, spacing: 12) {
                Text("Total Debits: \(summary.totalDebits, specifier: "%.2f")")
                Text("Total Credits: \(summary.totalCredits, specifier: "%.2f")")
                Text("Net Balance: \(summary.netBalance, specifier: "%.2f")")
                Text("Top Spending Category: \(summary.topSpendingCategory ?? "N/A")")
            }
            .padding()
            
        }
    }
}

#Preview {
    ContentView()
}

