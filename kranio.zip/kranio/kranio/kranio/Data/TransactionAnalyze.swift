//
//  TransactionAnalyze.swift
//  kranio-test
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

import Foundation

enum TransactionType {
    case debit, credit
}

struct Transaction {
    let id: String
    let accountId: String
    let type: TransactionType
    let amount: Double
    let category: String
}


class TransactionAnalyzer {
    func analyzeTransactions(_ transactions: [Transaction]) -> AccountSummary {
        let totalDebits = transactions
            .filter { $0.type == .debit }
            .reduce(0) { $0 + $1.amount }
        let totalCredits = transactions
            .filter { $0.type == .credit }
            .reduce(0) { $0 + $1.amount }
        let netBalance = totalCredits - totalDebits

        let debitCategories = transactions
            .filter { $0.type == .debit }
            .reduce(into: [String: Double]()) { dict, tx in
                dict[tx.category, default: 0] += tx.amount
            }
        let topSpendingCategory = debitCategories.max { $0.value < $1.value }?.key

        return AccountSummary(
            totalDebits: totalDebits,
            totalCredits: totalCredits,
            netBalance: netBalance,
            topSpendingCategory: topSpendingCategory
        )
    }
}
