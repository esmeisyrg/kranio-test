//
//  TransactionMapper.swift
//  kranio-test
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

struct TransactionMapper {
    static func map(input: TransactionInputModel) -> Transaction? {
        guard let type = TransactionType(rawValue: input.type.lowercased()) else { return nil }
        return Transaction(
            id: input.id,
            accountId: input.accountId,
            type: type,
            amount: input.amount,
            category: input.category
        )
    }
}

extension TransactionType {
    init?(rawValue: String) {
        switch rawValue {
        case "debit": self = .debit
        case "credit": self = .credit
        default: return nil
        }
    }
}
