//
//  TransactionUseCase.swift
//  kranio
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

import Foundation

/// Use case for analyzing a list of transactions and producing an account summary
struct AnalyzeTransactionsUseCase {
    private let analyzer = TransactionAnalyzer()

    func execute(transactions: [Transaction]) -> AccountSummary {
        return analyzer.analyzeTransactions(transactions)
    }
}
