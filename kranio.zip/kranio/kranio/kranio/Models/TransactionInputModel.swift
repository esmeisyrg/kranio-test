//
//  TransactionInputModel.swift
//  kranio
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

/// Model representing the input of account transactions
struct TransactionInputModel {
    let id: String
    let accountId: String
    let type: String
    let amount: Double
    let category: String
}
