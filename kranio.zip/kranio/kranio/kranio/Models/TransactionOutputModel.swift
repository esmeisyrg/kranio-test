//
//  TransactionOutputModel.swift
//  kranio
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

/// Model representing the summary of account transactions
struct AccountSummary {
    let totalDebits: Double
    let totalCredits: Double
    let netBalance: Double
    let topSpendingCategory: String?
}
