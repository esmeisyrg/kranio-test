//
//  kranioApp.swift
//  kranio
//
//  Created by Esmeisy Ramirez on 8/8/25.
//

import SwiftUI

@main
struct kranioApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
